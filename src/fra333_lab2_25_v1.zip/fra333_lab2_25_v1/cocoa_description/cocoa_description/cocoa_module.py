#!/usr/bin/python3

def dummy_function():
    pass

dummy_var = 0.0
